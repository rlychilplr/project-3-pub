<link rel="stylesheet" href="css/make-post.css">
<div class="make-post-wrapper flex">
    <form autocomplete="off" method="post" action="submit-post.php">
        <textarea name="chanses" class="make-post-text-area" maxlength="500" placeholder="you are limited to 500 characters per message"></textarea>
        <input type="submit" name="submit" class="make-post-submit">
    </form>
</div>