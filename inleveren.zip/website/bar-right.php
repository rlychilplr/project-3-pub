<div class="bar-right">
    <link href="css/bar-right.css" rel="stylesheet">
    <img src="img/new-logo.png" class="right-bar-logo">
    <div class="flex flex-column ">
        <button onclick="location.href = '#';">Lorem</button>
        <button onclick="location.href = '#';">Lorem</button>
        <button onclick="location.href = '#';">Lorem</button>
        <button onclick="location.href = '#';">Lorem</button>
    </div>
</div>