<footer class="flex flex-row">
    <link href="css/footer.css" rel="stylesheet">
    <div class="footer-container flex">
        <div class="whitespace-footer"></div>
        <div class="footer-nav center-content flex">
            <ul class="flex remove-padding-and-margin center-content rm-text-deco">
                <li><a href="About.php">About&nbsp;us</a></li>
                <li><a href="privacy policy.txt" target="_blank">Privacy&nbsp;Policy</a></li>
                <li><a href="cookie policy.txt" target="_blank">Cookie&nbsp;Policy</a></li>
                <li><a href="https://github.com/rlychilplr/project-3" target="_blank">Code</a></li>
            </ul>
        </div>
    </div>
</footer>